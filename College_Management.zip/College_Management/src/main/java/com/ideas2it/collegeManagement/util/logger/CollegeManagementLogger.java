package com.ideas2it.collegeManagement.util.logger;

public class CollegeManagementLogger {

}
